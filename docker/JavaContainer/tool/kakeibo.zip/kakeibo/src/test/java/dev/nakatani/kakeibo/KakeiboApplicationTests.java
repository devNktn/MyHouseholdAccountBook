package dev.nakatani.kakeibo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakeiboApplicationTests {

	@Test
	void contextLoads() {
	}

}
